import React, { useState } from "react";
import FormContext from "./FormContext";

const FormState = (props) => {
  const [student, setStudent] = useState([
    { name: "Nikunj", age: 22, email: "nikunjgupta102@gmail.com" },
  ]);
  const [addFormData, setAddFormData] = useState({
    name: "",
    age: "",
    email: "",
  });
  return (
    <FormContext.Provider
      value={{ student, setStudent, addFormData, setAddFormData }}
    >
      {props.children}
    </FormContext.Provider>
  );
};

export default FormState;
