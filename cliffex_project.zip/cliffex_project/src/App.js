import Home from "./components/pages/Home";
import Form from "./components/pages/Form";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import FormState from "./context/form/FormState";

function App() {
  return (
    <FormState>
      <Router>
        <div>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/form" element={<Form />} />
          </Routes>
        </div>
      </Router>
    </FormState>
  );
}

export default App;
