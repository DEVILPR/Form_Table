import { Link } from "react-router-dom";
import { useContext } from "react";
import FormContext from "../../context/form/FormContext";

const Home = () => {
  const a = useContext(FormContext);
  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>name</th>
            <th>age</th>
            <th>email</th>
          </tr>
        </thead>
        <tbody>
          {a.student.map((val, index) => (
            <tr>
              <td>{val.name}</td>
              <td>{val.age}</td>
              <td>{val.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link to="/form">
        <button>FORM</button>
      </Link>
    </div>
  );
};

export default Home;
