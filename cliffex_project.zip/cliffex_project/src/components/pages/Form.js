import { Link } from "react-router-dom";
import { useContext } from "react";
import FormContext from "../../context/form/FormContext";

const Form = () => {
  const b = useContext(FormContext);
  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...b.addFormData };
    newFormData[fieldName] = fieldValue;

    b.setAddFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newValue = {
      name: b.addFormData.name,
      age: b.addFormData.age,
      email: b.addFormData.email,
    };

    const newValues = { ...b.student, newValue };
    b.setStudent(newValues);
  };

  return (
    <div>
      <form action="" onSubmit={handleAddFormSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          onChange={handleAddFormChange}
        />
        <input
          type="number"
          name="age"
          placeholder="Age"
          onChange={handleAddFormChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          onChange={handleAddFormChange}
        />
        <button type="submit">Submit</button>
      </form>

      <Link to="/">
        <button>Home</button>
      </Link>
    </div>
  );
};

export default Form;
